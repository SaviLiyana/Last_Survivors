  <div class="row">
    <div class="admin-background">
      <div class="col-md-6 mx-auto py-5">
        <div class="card rounded-3 border-0">
          <div class="card-body">
            <h1 align="center" class="py-3">Start Market Share</h1>
            <h4 class="py-3 text-danger">
              <ul>
                <li class="py-2">This is the button for start the market.</li>
                <li class="py-2">After the market is started, you've to wait until the market is closed in 5 minutes.</li>
                <li class="py-2">But while the market is running, you can freely access the clients' facilities.</li>
              </ul>
            </h4>
            <a href="<?php echo site_url('Startup/start'); ?>" class="btn btn-warning btn-block">Start</a>
          </div>
        </div>
      </div>
    </div>
  </div>
