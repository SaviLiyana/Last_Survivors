  </div>
</div>
  <footer class="bg-info">
      <div class="text-center text-white py-3">
           Stock Market Simulation Game v0.1<br>Developed By <a href="<?php echo base_url(); ?>team">Last Survivors</a><br> &copy 2018 - All Rights Reserved
      </div>
  </footer>

  <script src="<?php echo base_url(); ?>assets/js/jquery-3.3.1.slim.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/custom.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/bootstrap.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/canvasjs.min.js"></script>
  <script src="<?php echo base_url(); ?>assets/js/jquery.dataTables.min.js"></script>
  
  </body>
</html>
